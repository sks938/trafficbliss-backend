from flask import Blueprint, request, jsonify
from extensions import mysql

gov_bp = Blueprint("gov", __name__)

# Broadcast advisory
@gov_bp.route("/broadcast", methods=["POST"])
def broadcast_advisory():
    data = request.json
    message = data.get("message")

    if not message:
        return jsonify({"message": "Message is required"}), 400

    cur = mysql.connection.cursor()
    cur.execute(
        "INSERT INTO advisories(message) VALUES(%s)",
        (message,)
    )

    mysql.connection.commit()
    cur.close()

    return jsonify({
        "message": "Advisory broadcasted successfully"
    })


# Get all advisories
@gov_bp.route("/advisories", methods=["GET"])
def get_advisories():
    cur = mysql.connection.cursor()
    cur.execute("SELECT id, message, created_at FROM advisories ORDER BY created_at DESC")
    advisories = cur.fetchall()
    cur.close()

    result = []
    for adv in advisories:
        result.append({
            "id": adv[0],
            "message": adv[1],
            "created_at": str(adv[2])
        })

    return jsonify(result)   