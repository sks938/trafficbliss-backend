from flask import Blueprint, request, jsonify
from extensions import mysql

parking_bp = Blueprint("parking", __name__)

@parking_bp.route("/rent", methods=["POST"])
def rent_space():
    data = request.json
    space_id = data.get("space_id")
    renter_id = data.get("renter_id")

    cur = mysql.connection.cursor()

    cur.execute("SELECT price, user_id FROM parking_spaces WHERE id=%s", (space_id,))
    space = cur.fetchone()

    if not space:
        return jsonify({"message": "Parking space not found"}), 404

    price = float(space[0])
    owner_id = space[1]

    commission = price * 0.15
    owner_amount = price - commission

    # Deduct renter
    cur.execute(
        "UPDATE users SET wallet_balance = wallet_balance - %s WHERE id=%s",
        (price, renter_id)
    )

    # Add owner earning
    cur.execute(
        "UPDATE users SET wallet_balance = wallet_balance + %s WHERE id=%s",
        (owner_amount, owner_id)
    )

    # Mark as rented
    cur.execute(
        "UPDATE parking_spaces SET is_rented = TRUE WHERE id=%s",
        (space_id,)
    )

    mysql.connection.commit()
    cur.close()

    return jsonify({
        "message": "Parking rented successfully",
        "paid": price,
        "owner_received": owner_amount,
        "commission": commission
    })