from extensions import socketio
from flask_socketio import emit, join_room

# user joins chat room
@socketio.on("join")
def join(data):

    room = data["room"]
    join_room(room)

    emit("message",{
        "sender":"system",
        "message":"User joined chat"
    },room=room)


# send message
@socketio.on("send_message")
def handle_message(data):

    room = data["room"]
    sender = data["sender"]
    message = data["message"]

    emit("message",{
        "sender":sender,
        "message":message
    },room=room)


# auto reply
@socketio.on("parkbot")
def parkbot(data):

    text = data["message"].lower()

    if "parking" in text:
        reply = "Nearby parking is available near City Mall."
    elif "wallet" in text:
        reply = "Open Wallet section to add money."
    else:
        reply = "Hello! I am ParkBot. How can I help?"

    emit("bot_reply",{
        "sender":"ParkBot",
        "message":reply
    })