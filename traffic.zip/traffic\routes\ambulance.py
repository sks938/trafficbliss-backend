# from flask import Blueprint, request, jsonify
# from extensions import mysql

# ambulance_bp = Blueprint("ambulance", __name__)

# # Request ambulance
# @ambulance_bp.route("/request", methods=["POST"])
# def request_ambulance():
#     data = request.json

#     user_id = data.get("user_id")
#     patient_name = data.get("patient_name")
#     location = data.get("location")
#     emergency_type = data.get("emergency_type")

#     cur = mysql.connection.cursor()

#     cur.execute("""
#         INSERT INTO ambulance_requests(user_id, patient_name, location, emergency_type)
#         VALUES(%s,%s,%s,%s)
#     """, (user_id, patient_name, location, emergency_type))

#     mysql.connection.commit()
#     cur.close()

#     return jsonify({
#         "message": "Ambulance request sent successfully 🚑"
#     })


# # View all ambulance requests
# @ambulance_bp.route("/requests", methods=["GET"])
# def get_requests():

#     cur = mysql.connection.cursor()

#     cur.execute("SELECT * FROM ambulance_requests ORDER BY created_at DESC")
#     requests = cur.fetchall()

#     cur.close()

#     result = []

#     for r in requests:
#         result.append({
#             "id": r[0],
#             "user_id": r[1],
#             "patient_name": r[2],
#             "location": r[3],
#             "emergency_type": r[4],
#             "status": r[5],
#             "created_at": str(r[6])
#         })

#     return jsonify(result)


# # Accept ambulance request
# @ambulance_bp.route("/accept/<int:request_id>", methods=["POST"])
# def accept_request(request_id):

#     cur = mysql.connection.cursor()

#     cur.execute("""
#         UPDATE ambulance_requests
#         SET status='assigned'
#         WHERE id=%s
#     """, (request_id,))

#     mysql.connection.commit()
#     cur.close()

#     return jsonify({
#         "message": "Ambulance assigned successfully"
#     })