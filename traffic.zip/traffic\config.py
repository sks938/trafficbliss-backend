import os

class Config:
    SECRET_KEY = "trafficbliss_secret"
    MYSQL_HOST = "localhost"
    MYSQL_USER = "root"
    MYSQL_PASSWORD = "yourpassword"
    MYSQL_DB = "trafficbliss"
    JWT_SECRET_KEY = "jwt_secret"