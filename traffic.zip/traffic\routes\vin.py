from flask import Blueprint, request, jsonify
from extensions import mysql

vin_bp = Blueprint("vin", __name__)

# Bind VIN to user
@vin_bp.route("/bind", methods=["POST"])
def bind_vin():
    data = request.json
    user_id = data.get("user_id")
    vin_number = data.get("vin")

    if not user_id or not vin_number:
        return jsonify({"message": "Missing user_id or VIN"}), 400

    cur = mysql.connection.cursor()

    cur.execute(
        "INSERT INTO vehicles(user_id, vin, rc_verified) VALUES(%s,%s,%s)",
        (user_id, vin_number, True)
    )

    mysql.connection.commit()
    cur.close()

    return jsonify({
        "message": "VIN linked successfully",
        "vin": vin_number
    })


# Get user VINs
@vin_bp.route("/list/<int:user_id>", methods=["GET"])
def get_user_vins(user_id):
    cur = mysql.connection.cursor()
    cur.execute(
        "SELECT vin, rc_verified FROM vehicles WHERE user_id=%s",
        (user_id,)
    )

    vins = cur.fetchall()
    cur.close()

    result = []
    for v in vins:
        result.append({
            "vin": v[0],
            "rc_verified": bool(v[1])
        })

    return jsonify(result)