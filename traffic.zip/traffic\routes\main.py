import socketio
from fastapi import FastAPI

# Create Socket.IO server
sio = socketio.AsyncServer(async_mode='asgi', cors_allowed_origins='*')

# FastAPI app
app = FastAPI()

# Combine FastAPI + Socket.IO
socket_app = socketio.ASGIApp(sio, app)

# Store driver locations (in-memory)
driver_locations = {}

# When client connects
@sio.event
async def connect(sid, environ):
    print(f"Client connected: {sid}")

# When client disconnects
@sio.event
async def disconnect(sid):
    print(f"Client disconnected: {sid}")

# Receive driver location
@sio.event
async def driverLocation(sid, data):
    """
    data = {
        "driverId": "123",
        "lat": 17.3850,
        "lng": 78.4867
    }
    """

    driver_id = data.get("driverId")

    # Save location
    driver_locations[driver_id] = {
        "lat": data.get("lat"),
        "lng": data.get("lng")
    }

    print("Updated:", driver_locations)

    # Send to all users (riders)
    await sio.emit("updateDriverLocation", {
        "driverId": driver_id,
        "lat": data.get("lat"),
        "lng": data.get("lng")
    })

# REST API to get all drivers
@app.get("/drivers")
async def get_drivers():
    return driver_locations