from flask import Blueprint, request, jsonify
from extensions import mysql

marketplace_bp = Blueprint("marketplace", __name__)

# Vendor onboarding
@marketplace_bp.route("/vendor/register", methods=["POST"])
def register_vendor():

    data = request.json
    name = data.get("name")
    phone = data.get("phone")
    shop_name = data.get("shop_name")

    cur = mysql.connection.cursor()

    cur.execute(
        "INSERT INTO vendors(name, phone, shop_name) VALUES(%s,%s,%s)",
        (name, phone, shop_name)
    )

    mysql.connection.commit()
    cur.close()

    return jsonify({"message": "Vendor registered successfully"})


# Add product
@marketplace_bp.route("/product/add", methods=["POST"])
def add_product():

    data = request.json

    vendor_id = data.get("vendor_id")
    # category_id = data.get("category_id")
    name = data.get("name")
    category = data.get("category")
    price = data.get("price")
    description = data.get("description")

    cur = mysql.connection.cursor()

    cur.execute(
        """
        INSERT INTO products(vendor_id,name,category,price,description)
        VALUES(%s,%s,%s,%s,%s)
        """,
        (vendor_id, name, category, price, description)
    )

    mysql.connection.commit()
    cur.close()

    return jsonify({"message": "Product added successfully"})


# Get products (category filter)
@marketplace_bp.route("/products", methods=["GET"])
def get_products():

    category = request.args.get("category")

    cur = mysql.connection.cursor()

    if category:
        cur.execute("""
        SELECT p.id,p.name,p.price,c.name
        FROM products p
        JOIN categories c ON p.category_id=c.id
        WHERE p.category_id=%s
        """,(category,))
    else:
        cur.execute("""
        SELECT p.id,p.name,p.price,c.name
        FROM products p
        JOIN categories c ON p.category_id=c.id
        """)

    # if category:
    #     cur.execute(
    #         "SELECT id,name,category,price FROM products WHERE category=%s",
    #         (category,)
    #     )
    # else:
    #     cur.execute(
    #         "SELECT id,name,category,price FROM products"
    #     )

    products = cur.fetchall()
    cur.close()

    result = []

    for p in products:
        result.append({
            "id": p[0],
            "name": p[1],
            "category": p[2],
            "price": float(p[3])
        })

    return jsonify(result)


# Add to cart
@marketplace_bp.route("/cart/add", methods=["POST"])
def add_to_cart():

    data = request.json

    user_id = data.get("user_id")
    product_id = data.get("product_id")
    quantity = data.get("quantity")

    cur = mysql.connection.cursor()

    cur.execute(
        """
        INSERT INTO cart(user_id,product_id,quantity)
        VALUES(%s,%s,%s)
        """,
        (user_id, product_id, quantity)
    )

    mysql.connection.commit()
    cur.close()

    return jsonify({"message": "Product added to cart"})