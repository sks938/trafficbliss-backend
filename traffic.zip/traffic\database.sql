CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100),
    email VARCHAR(100) UNIQUE,
    password VARCHAR(255),
    wallet_balance DECIMAL(10,2) DEFAULT 0
);

CREATE TABLE vehicles (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    vin VARCHAR(50),
    rc_verified BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

CREATE TABLE parking_spaces (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    location VARCHAR(255),
    price DECIMAL(10,2),
    is_rented BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

CREATE TABLE transactions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    type VARCHAR(50),
    amount DECIMAL(10,2),
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

CREATE TABLE messages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    sender_id INT,
    receiver_id INT,
    message TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE advisories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    message TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- CREATE TABLE ambulance_requests (
--     id INT AUTO_INCREMENT PRIMARY KEY,
--     user_id INT,
--     patient_name VARCHAR(100),
--     location VARCHAR(255),
--     emergency_type VARCHAR(100),
--     status VARCHAR(50) DEFAULT 'pending',
--     created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
-- );

-- CREATE TABLE ambulances (
--     id INT AUTO_INCREMENT PRIMARY KEY,
--     driver_name VARCHAR(100),
--     phone VARCHAR(20),
--     vehicle_number VARCHAR(50),
--     status VARCHAR(50) DEFAULT 'available'
-- );

CREATE TABLE vendors (
id INT AUTO_INCREMENT PRIMARY KEY,
name VARCHAR(100),
phone VARCHAR(20),
shop_name VARCHAR(100),
created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE products (
id INT AUTO_INCREMENT PRIMARY KEY,
vendor_id INT,
name VARCHAR(100),
category VARCHAR(100),
price DECIMAL(10,2),
description TEXT,
created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE cart (
id INT AUTO_INCREMENT PRIMARY KEY,
user_id INT,
product_id INT,
quantity INT DEFAULT 1,
created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE roadblocks (
id INT AUTO_INCREMENT PRIMARY KEY,
title VARCHAR(100),
description TEXT,
latitude DECIMAL(10,8),
longitude DECIMAL(11,8),
created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE roadblocks (
id INT AUTO_INCREMENT PRIMARY KEY,
title VARCHAR(100),
description TEXT,
latitude DECIMAL(10,8),
longitude DECIMAL(11,8),
created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE roadblocks (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(100),
    latitude DOUBLE,
    longitude DOUBLE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE parking_locations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100),
    latitude DOUBLE,
    longitude DOUBLE,
    available_slots INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE enforcement_alerts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(100),
    latitude DOUBLE,
    longitude DOUBLE,
    severity VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE gov_bulletins (
    id INT AUTO_INCREMENT PRIMARY KEY,
    authority VARCHAR(100),
    message TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE driver_locations (
id INT AUTO_INCREMENT PRIMARY KEY,
driver_id INT,
latitude DOUBLE,
longitude DOUBLE,
updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);