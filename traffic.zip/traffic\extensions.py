from flask_mysqldb import MySQL
from flask_jwt_extended import JWTManager
from flask_socketio import SocketIO

mysql = MySQL()
jwt = JWTManager()
socketio = SocketIO(cors_allowed_origins="*")