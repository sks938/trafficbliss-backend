from flask import Blueprint, request, jsonify
from flask_mysqldb import MySQL
from flask_jwt_extended import create_access_token
from extensions import mysql
from routes.wallet import wallet_bp
import hashlib

auth_bp = Blueprint("auth", __name__)

@auth_bp.route("/register", methods=["POST"])
def register():
    data = request.json
    password = hashlib.sha256(data["password"].encode()).hexdigest()

    cur = mysql.connection.cursor()
    cur.execute("INSERT INTO users(name,email,password) VALUES(%s,%s,%s)",
                (data["name"], data["email"], password))
    mysql.connection.commit()
    return jsonify({"message": "User Registered"})


@auth_bp.route("/login", methods=["POST"])
def login():
    data = request.json
    password = hashlib.sha256(data["password"].encode()).hexdigest()

    cur = mysql.connection.cursor()
    cur.execute("SELECT id FROM users WHERE email=%s AND password=%s",
                (data["email"], password))
    user = cur.fetchone()

    if user:
        token = create_access_token(identity=user[0])
        return jsonify({"token": token})
    return jsonify({"message": "Invalid Credentials"}), 401