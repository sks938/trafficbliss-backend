from flask import Blueprint
from flask_socketio import emit
from extensions import socketio

tracking_bp = Blueprint("tracking", __name__)

# Store live drivers (in-memory)
drivers = {}

@socketio.on("sendLocation")
def handle_location(data):

    driver_id = data.get("driver_id")
    lat = data.get("lat")
    lng = data.get("lng")

    if not driver_id:
        return

    # Save latest location
    drivers[driver_id] = {
        "lat": lat,
        "lng": lng
    }

    # Broadcast to all users
    emit("receiveLocation", {
        "driver_id": driver_id,
        "lat": lat,
        "lng": lng
    }, broadcast=True)