from flask import Blueprint, request, jsonify
from extensions import mysql

wallet_bp = Blueprint("wallet", __name__)

# View wallet balance
@wallet_bp.route("/balance/<int:user_id>", methods=["GET"])
def get_balance(user_id):
    cur = mysql.connection.cursor()
    cur.execute("SELECT wallet_balance FROM users WHERE id=%s", (user_id,))
    result = cur.fetchone()
    cur.close()

    if result:
        return jsonify({"balance": float(result[0])})
    return jsonify({"message": "User not found"}), 404


# Add money
@wallet_bp.route("/add", methods=["POST"])
def add_money():
    data = request.json
    user_id = data["user_id"]
    amount = float(data["amount"])

    cur = mysql.connection.cursor()
    cur.execute(
        "UPDATE users SET wallet_balance = wallet_balance + %s WHERE id=%s",
        (amount, user_id)
    )

    cur.execute(
        "INSERT INTO transactions(user_id,type,amount,description) VALUES(%s,%s,%s,%s)",
        (user_id, "credit", amount, "Wallet Top-up")
    )

    mysql.connection.commit()
    cur.close()

    return jsonify({"message": "Money Added Successfully"})