from flask import Blueprint, request, jsonify
from extensions import mysql

chat_bp = Blueprint("chat", __name__)

@chat_bp.route("/status")
def status():
    return jsonify({
        "message": "TrafficBliss Chat Service Running"
    })

# Send message
@chat_bp.route("/send", methods=["POST"])
def send_message():
    data = request.json
    sender_id = data.get("sender_id")
    receiver_id = data.get("receiver_id")
    message = data.get("message")

    if not sender_id or not receiver_id or not message:
        return jsonify({"message": "Missing required fields"}), 400

    cur = mysql.connection.cursor()

    cur.execute(
        "INSERT INTO messages(sender_id, receiver_id, message) VALUES(%s,%s,%s)",
        (sender_id, receiver_id, message)
    )

    mysql.connection.commit()
    cur.close()

    return jsonify({"message": "Message sent successfully"})


# Get chat between two users
@chat_bp.route("/conversation/<int:user1>/<int:user2>", methods=["GET"])
def get_conversation(user1, user2):
    cur = mysql.connection.cursor()

    cur.execute("""
        SELECT sender_id, receiver_id, message, created_at
        FROM messages
        WHERE (sender_id=%s AND receiver_id=%s)
        OR (sender_id=%s AND receiver_id=%s)
        ORDER BY created_at ASC
    """, (user1, user2, user2, user1))

    messages = cur.fetchall()
    cur.close()

    result = []
    for msg in messages:
        result.append({
            "sender_id": msg[0],
            "receiver_id": msg[1],
            "message": msg[2],
            "created_at": str(msg[3])
        })

    return jsonify(result)