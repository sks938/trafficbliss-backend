from flask import Flask, jsonify
from flask_cors import CORS
from config import Config
from extensions import mysql, jwt, socketio
#from routes.ambulance import ambulance_bp
from routes.marketplace import marketplace_bp
# from routes.map import map_bp
# form routes.main import fastapi_bp
from routes.live_map import live_map_bp

app = Flask(__name__)
app.config.from_object(Config)
# app.config['MYSQL_HOST'] = 'localhost'
# app.config['MYSQL_USER'] = 'root'
# app.config['MYSQL_PASSWORD'] = ''
# app.config['MYSQL_DB'] = 'trafficbliss'

mysql.init_app(app)
jwt.init_app(app)
CORS(app)
socketio.init_app(app)

drivers = {}

@socketio.on("driverLocation")
def handle_driver_location(data):
    driver_id = data.get("driver_id")
    lat = data.get("lat")
    lng = data.get("lng")

    drivers[driver_id] = {"lat": lat, "lng": lng}

    # Broadcast to all users
    socketio.emit("updateDriverLocation", {
        "driver_id": driver_id,
        "lat": lat,
        "lng": lng
    })

@app.route("/")
def home():
    return jsonify({
        "message": "TrafficBliss Backend Running Successfully 🚦"
    })


from routes.auth import auth_bp
from routes.wallet import wallet_bp
from routes.parking import parking_bp
from routes.vin import vin_bp
from routes.chat import chat_bp
from routes.gov import gov_bp
from routes.live_map import live_map_bp
from routes.tracking import tracking_bp


app.register_blueprint(auth_bp, url_prefix="/api/auth")
app.register_blueprint(wallet_bp, url_prefix="/api/wallet")
app.register_blueprint(parking_bp, url_prefix="/api/parking")
app.register_blueprint(vin_bp, url_prefix="/api/vin")
app.register_blueprint(chat_bp, url_prefix="/api/chat")
app.register_blueprint(gov_bp, url_prefix="/api/gov")
#app.register_blueprint(ambulance_bp, url_prefix="/api/ambulance")
app.register_blueprint(marketplace_bp, url_prefix="/api/marketplace")
# app.register_blueprint(map_bp, url_prefix="/api/map")
app.register_blueprint(live_map_bp, url_prefix="/api/map")
app.register_blueprint(tracking_bp)

from services.chat_service import *

if __name__ == "__main__":
    app.run(debug=False)