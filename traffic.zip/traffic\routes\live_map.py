from flask import Blueprint, jsonify
from extensions import mysql

live_map_bp = Blueprint("live_map", __name__)

# Roadblocks
@live_map_bp.route("/roadblocks", methods=["GET"])
def roadblocks():
    cur = mysql.connection.cursor()
    cur.execute("SELECT id,title,latitude,longitude FROM roadblocks")
    data = cur.fetchall()
    cur.close()

    return jsonify([
        {"id": r[0], "title": r[1], "lat": float(r[2]), "lng": float(r[3])}
        for r in data
    ])


# Parking
@live_map_bp.route("/parking", methods=["GET"])
def parking():
    cur = mysql.connection.cursor()
    cur.execute("SELECT id,name,latitude,longitude,available_slots FROM parking_locations")
    data = cur.fetchall()
    cur.close()

    return jsonify([
        {
            "id": p[0],
            "name": p[1],
            "lat": float(p[2]),
            "lng": float(p[3]),
            "slots": p[4]
        }
        for p in data
    ])


# Enforcement alerts
@live_map_bp.route("/alerts", methods=["GET"])
def alerts():
    cur = mysql.connection.cursor()
    cur.execute("SELECT id,title,latitude,longitude,severity FROM enforcement_alerts")
    data = cur.fetchall()
    cur.close()

    return jsonify([
        {
            "id": a[0],
            "title": a[1],
            "lat": float(a[2]),
            "lng": float(a[3]),
            "severity": a[4]
        }
        for a in data
    ])


# Government bulletin
@live_map_bp.route("/bulletins", methods=["GET"])
def bulletins():
    cur = mysql.connection.cursor()
    cur.execute("SELECT authority,message FROM gov_bulletins ORDER BY created_at DESC")
    data = cur.fetchall()
    cur.close()

    return jsonify([
        {"authority": b[0], "message": b[1]}
        for b in data
    ])